<?php

use App\Http\Controllers\FirstController;
use Illuminate\Support\Facades\Route;

Route::get('/', 
function (){
    return view('index');
} 
);

Route::get('/page2', 
function(){
    return view('page2');
}
);
  
Route::get('/about',
    [FirstController::class, 'index']
);